$(document).ready(function () {
    $('ul.tabs').tabs();
    $('.materialboxed').materialbox();
    $(".button-collapse").sideNav();
    $('.tooltipped').tooltip({ delay: 50 });
});