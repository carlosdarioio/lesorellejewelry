GrandNode Theme for nopCommerce 3.80
version: 3.81.3

What`s new?
 Added possbility to change colors directly from admin panel (need install widget first).
 May add own colors from admin panel.
 
Predefined colors:
	Brackwhite
	Blue
	Bluegray
	Gray
	Green
	Lightblue
	Orange
	Purple
	Red
	Yellow

Fix 3.81.6:
- estimate shipping fix
- back to top with color change
- back to top icon change
- define if use Materializee or Font Awesome Icon

Fix 3.81.2:
- password recovery
- css for menu haader
- color for desktop footer topic 
- added widget to choose color from admin panel
- rtl support for color change

Fix 3.80.7:
- selection colors
- product attributes
- private messages

Fix 3.80.4:
- search board basic area
- advanced board search button
- view all activ topics button
