$(document).ready(function () {
    $('ul.tabs').tabs();
    $('.materialboxed').materialbox();
    $(".button-collapse").sideNav();
});